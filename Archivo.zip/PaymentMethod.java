package ParcialDepo;

public interface PaymentMethod {

}
