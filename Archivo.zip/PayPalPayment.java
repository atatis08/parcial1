package ParcialDepo;

public class PayPalPayment extends AbstractPaymentMethod {
 private String email;
 
public PayPalPayment(String email) {
	this.email=email;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}


}
