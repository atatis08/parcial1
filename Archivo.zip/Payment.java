package ParcialDepo;

public class Payment {

	public String DOLLAR = "USD";
	public String EURO = "EUR";
	public String COLPESO="COP";
	private int amount;
	private String currency;
	private int id;
	
	
public Payment(int id,int amount,String currency) {
	this.id=id;
	this.amount = amount;
	this.currency = currency;
}


public int getAmount() {
	return amount;
}




public String getCurrency() {
	return currency;
}






}
