package ParcialDepo;

public class BankTransferPayment extends AbstractPaymentMethod {

private String bankAccountNumber;

public BankTransferPayment (String bankAccountNumber) {
	this.bankAccountNumber = bankAccountNumber;
}

		
	
public String getBankAccountNumber() {
	return bankAccountNumber;
}





public void setBankAccountNumber(String bankAccountNumber) {
	this.bankAccountNumber = bankAccountNumber;
}






	
}



