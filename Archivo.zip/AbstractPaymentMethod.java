package ParcialDepo;

public abstract class AbstractPaymentMethod implements PaymentMethod{

	private double transactionFee;
	private int processingTime;
	
public AbstractPaymentMethod(double fee, int time) {
	this.transactionFee = fee;
	this.processingTime = time;
}

public double getTransactionFee() {
	return transactionFee;
}




public int getProcessingTime() {
	return processingTime;
}



}

