package ParcialDepo;

public class CreditCardPayment extends AbstractPaymentMethod {
 private String cardNumber;
 private String cardHolderName;
 
 public CreditCardPayment(String CardNumber,String CardHolderName) {
	 
}

public String getCardNumber() {
	return cardNumber;
}

public void setCardNumber(String cardNumber) {
	this.cardNumber = cardNumber;
}

public String getCardHolderName() {
	return cardHolderName;
}

public void setCardHolderName(String cardHolderName) {
	this.cardHolderName = cardHolderName;
}

 
}
